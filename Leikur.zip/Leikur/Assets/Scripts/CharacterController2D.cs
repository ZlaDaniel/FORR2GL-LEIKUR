using UnityEngine;
using UnityEngine.Events;

public class CharacterController2D : MonoBehaviour
{
	[SerializeField] private float m_JumpForce = 400f;// stilling krafts � hoppi
    [Range(0, .3f)] [SerializeField] private float m_MovementSmoothing = .05f;// hversu miki� � a� gera hreyfinguna e�lilegri
	[SerializeField] private bool m_AirControl = false;// true e�a false hvort leikma�ur geti hreyft sig � lofti, byrjar � false og breytist � true �egar � vi�
	[SerializeField] private LayerMask m_WhatIsGround;// �kve�ur hva� er g�lf fyrir leikmanninum
	[SerializeField] private Transform m_GroundCheck;// Sta�ur � leikmanninum sem leitar a� g�lfi
	[SerializeField] private Transform m_CeilingCheck;// Sta�ur � leikmanninum sem leitar a� lofti

    const float k_GroundedRadius = .2f;
	private bool m_Grounded;// Hvort er leikma�ur � g�lfi e�a lofti
	const float k_CeilingRadius = .2f;
	private Rigidbody2D m_Rigidbody2D;
	private bool m_FacingRight = true;// �kve�ur � hva�a �tt leikma�ur sn�r
	private Vector3 m_Velocity = Vector3.zero;

	[Header("Events")]
	[Space]

	public UnityEvent OnLandEvent;

	[System.Serializable]
	public class BoolEvent : UnityEvent<bool> { }

	private void Awake()
	{
		m_Rigidbody2D = GetComponent<Rigidbody2D>();

		if (OnLandEvent == null)
			OnLandEvent = new UnityEvent();

	}

	private void FixedUpdate()
	{
		bool wasGrounded = m_Grounded;
		m_Grounded = false;

		Collider2D[] colliders = Physics2D.OverlapCircleAll(m_GroundCheck.position, k_GroundedRadius, m_WhatIsGround);
		for (int i = 0; i < colliders.Length; i++)
		{
			if (colliders[i].gameObject != gameObject)
			{
				m_Grounded = true;
				if (!wasGrounded)
					OnLandEvent.Invoke();
			}
		}
	}


	public void Move(float move,bool crouch,bool jump)
	{
        //A�eins h�gt a� stj�rna leikmanninn ef hann er � j�r�u e�a �egar hann er � loftinu
		if (m_Grounded || m_AirControl)
		{

			//F�rir playerinn
			Vector3 targetVelocity = new Vector2(move * 10f, m_Rigidbody2D.velocity.y);
			//Gerir hreyfinguna e�lilegri
			m_Rigidbody2D.velocity = Vector3.SmoothDamp(m_Rigidbody2D.velocity, targetVelocity, ref m_Velocity, m_MovementSmoothing);

            //ef �a� er veri� a� hreyfa leikmanninn til h�gri og leikma�urinn sn�r til vinstri
			if (move > 0 && !m_FacingRight)
			{
				//sn�r leikmanninum
				Flip();
			}
            //ef �a� er veri� a� hreyfa leikmanninn til vinstri og leikma�urinn sn�r til h�gri
            else if (move < 0 && m_FacingRight)
			{
                //sn�r leikmanninum
                Flip();
			}
		}
		//Ef leikma�ur er � j�r�u og � a� hoppa
		if (m_Grounded && jump)
		{
			//b�tir �yngdarafli � leikmanninn
			m_Grounded = false;
			m_Rigidbody2D.AddForce(new Vector2(0f, m_JumpForce));
		}
	}


	private void Flip()
	{
		//Breytir hvernig leikma�urinn sn�r
		m_FacingRight = !m_FacingRight;

		Vector3 theScale = transform.localScale;
		theScale.x *= -1;
		transform.localScale = theScale;
	}
}
