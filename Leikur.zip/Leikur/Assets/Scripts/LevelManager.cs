﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class LevelManager : MonoBehaviour {

    public Transform spawnPoint, player;
    private Rigidbody2D playerRig;
    public GameObject deathParticles, spawnParticles;
    private SpriteRenderer playerSprite;
    public float respawnTime;//endurlífgunartími
    public static int score;
    public static int lives;
    public Text scoreText;
    public Text livesText;

    void Start ()
    {
        lives = 1;//lives byrjar í 3
        score = 0;//score byrjar í 0
        playerRig = player.GetComponent<Rigidbody2D>();
        playerSprite = player.GetComponent<SpriteRenderer>();
	}

	void Update ()
    {
		if(score < 0)
        {
            score = 0;
        }
        if (score == 25)
        {
            SceneManager.LoadScene(3);
        }
        scoreText.text = "Score: " + score;//breytir score textanum
        livesText.text = "Lives: " + lives;//breytir lives textanum
        if (lives < 1)// ef lives fer niður í 0 er breytt um scene og farið í game over scene
        {
            SceneManager.LoadScene(2);
        }
    }
    public static void AddLives()
    {
        lives += 1;
    }
    public static void AddPoints(int points)//stækkar score töluna
    {
        score += points;
    }
    public static void Reset()
    {
        score = 0;
    }
    public void Respawn()
    {
        StartCoroutine(RespawnCo());
        lives -= 1;
    }

    public IEnumerator RespawnCo()
    {
        Instantiate(deathParticles, player.position, player.rotation);//lætur particles birtast við dauða
        playerSprite.enabled = false;
        yield return new WaitForSeconds(respawnTime);
        player.position = spawnPoint.position;//lætur leikmann á byrjunarstað upp á nýtt
        playerRig.velocity = Vector3.zero;//lætur velocity í 0 svo leikmaður haldi ekki afram að hreyfast eftir dauða
        Instantiate(spawnParticles, spawnPoint.position, spawnPoint.rotation);//Lætur particles birtast við endurlífgun
        playerSprite.enabled = true;
    }
}
