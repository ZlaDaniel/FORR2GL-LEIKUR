﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class demantur : MonoBehaviour {

    public int points;//hversu mörg stig eru gefin fyrir hvern demant sem leikmaður nær

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.name == "Player")//skoðar hvort það se ekki orugglega leikmaðurinn sem er að koma við demantinn
        {
            LevelManager.AddPoints(points);// bætir við stigum
            if(LevelManager.score == 5 || LevelManager.score == 10 || LevelManager.score == 15 || LevelManager.score == 20)
            {
                LevelManager.AddLives();
            }
            Destroy(gameObject); // fjarlægir demantinn
        }
    }
}
